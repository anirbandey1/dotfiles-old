# Zathura

Install
```
sudo pacman -S zathura
sudo pacman -S zathura-pdf-mupdf
# sudo pacman -S zathura-pdf-poppler
```

To use this config file
```
gh repo clone awesomeDev12/zathura ~/.config/zathura
```
