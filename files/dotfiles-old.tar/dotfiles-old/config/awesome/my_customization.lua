-- My customization

-- local awful = require("awful")

-- awful.util.spawn_with_shell("bash ~/.config/awesome/init.sh")
os.execute("bash ~/.config/awesome/init.sh")
