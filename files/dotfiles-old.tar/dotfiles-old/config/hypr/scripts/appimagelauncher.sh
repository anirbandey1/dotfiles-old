#!/bin/bash

# app=`/bin/ls ~/applications/appimages/ | rofi -theme Arc-Dark -dmenu -p "Run :"` && ./applications/appimages/$app

# /bin/ls ~/applications/appimages/ | rofi -theme Arc-Dark -dmenu -p "Run "



# app=`/bin/ls ~/applications/appimages/ | rofi -theme Arc-Dark -dmenu -i -p "AppImage "` && ~/applications/appimages/$app



app=`/bin/ls ~/applications/appimages/ | wofi -G --dmenu -i -p "AppImage "`
~/applications/appimages/$app
