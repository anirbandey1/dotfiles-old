#!/bin/bash

# wsno=`hyprctl workspaces | grep "workspace ID" | wc  -l` 
# wsto=$((wsno+1))
# echo $wsto
# hyprctl dispatch workspace $wsto


for i in {1..9}; do
    if ! hyprctl workspaces | grep -q "workspace ID $i"; then
        # echo $i
        wsto=$((i))
        break
    fi
done



echo $wsto
hyprctl dispatch workspace $wsto
