# i3 window manager

Installation
```
sudo pacman -S i3
sudo pacman -S i3status
```
