# mpv

### To use this config
```
gh repo clone awesomeDev12/mpv ~/.config/mpv
```
or

```
git clone https://gihub.com/awesomeDev12/mpv ~/.config/mpv
```

### For reference

[Ask Ubuntu](https://askubuntu.com/questions/924692/how-to-change-keybinding-of-mpv-player)

[Default Keybindings](https://raw.githubusercontent.com/mpv-player/mpv/master/etc/input.conf)

[Command Line Interface](https://raw.githubusercontent.com/mpv-player/mpv/master/DOCS/man/input.rst)

