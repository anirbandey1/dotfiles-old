#!/bin/bash


# app=`/bin/cat ~/.config/qtile/lists/favourite_apps.txt | rofi -theme Arc-Dark -dmenu -i -p "Favourite "` && $app


app=`/bin/cat ~/.config/qtile/lists/favourite_apps.txt | wofi -G --dmenu -i -p "Favourite "` && $app
