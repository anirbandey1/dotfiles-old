# Awesome Window Manager

To use this config file
```
gh repo clone awesomeDev12/awesome ~/.config/awesome
```

For fonts
```
pacman -sS ttf-dejavu
sudo pacman -S ttf-dejavu
```



