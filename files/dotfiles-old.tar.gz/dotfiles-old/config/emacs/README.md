# Emacs config files

if emacs is no reading the config files it means that
either you have a **~/.emacs** file in the home directory
or a **~/.emacs.d/** directory in the home directory
Delete that file and create a **~/.config/emacs/** directory

You need emacs *version 28* to ensure this config works properly
especially color themes


