#!/bin/bash

# Get the output of `flatpak list`
# output=$(flatpak list)

# Use awk to print only the second word of each line starting from the second line
# echo "$output" | awk 'NR>1 {print $2}'


# Get the output of `flatpak list`
# output=$(flatpak list --columns=application)

if [ -f ~/.config/qtile/lists/flatpak_apps.txt ]; then
    app=`cat ~/.config/qtile/lists/flatpak_apps.txt | rofi -theme Arc-Dark -dmenu -i -p "Flatpak "` && flatpak run $app
else
    app=`flatpak list --columns=application | rofi -theme Arc-Dark -dmenu -i -p "Flatpak "` && flatpak run $app
fi


# app=`flatpak list --columns=application | rofi -theme Arc-Dark -dmenu -i -p "Flatpak "` && flatpak run $app
# echo $app
# flatpak run $app
