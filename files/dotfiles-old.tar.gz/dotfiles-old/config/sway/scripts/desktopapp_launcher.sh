#!/bin/bash

export QT_QPA_PLATFORMTHEME=qt5ct
export QT_STYLE_OVERRIDE=kvantum

# rofi -theme Arc-Dark -show drun
wofi -G --show drun
