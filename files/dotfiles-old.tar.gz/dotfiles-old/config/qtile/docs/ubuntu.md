# Ubuntu

Copy desktop entry
```
sudo cp /usr/share/xsessions/ubuntu.desktop /usr/share/xsessions/qtile.desktop
```

Make sure ~/.local/bin is in your $PATH

Add ~/.local/bin to path
```
export PATH=$PATH:/home/${USER}/.local/bin
```

