# Qtile


#### To use my config 
```
git clone https://github.com/awesomeDev12/qtile.git ~/.config/qtile
```
or 
```
gh repo clone awesomeDev12/qtile ~/.config/qtile
```

#### To copy default config
```
cp /usr/share/doc/qtile/default_config.py ~/.config/qtile/config.py
```
#### Reference
Brightness script taken from 
[xrandr-brightness-script](https://github.com/philippnormann/xrandr-brightness-script)
